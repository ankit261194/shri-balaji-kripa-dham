<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

$dir = __DIR__;
$fixed = [];

// 1. Scan and fix all backslashed files in current directory
$items = scandir($dir);
foreach ($items as $item) {
    if (strpos($item, '\\') !== false) {
        $realRelative = str_replace('\\', '/', $item);
        $targetPath = $dir . '/' . $realRelative;
        $targetDir = dirname($targetPath);
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        if (rename($dir . '/' . $item, $targetPath)) {
            $fixed[] = $item . " -> " . $realRelative;
        }
    }
}

// 2. If we are inside /public_html/shribalajikripadham, also copy/sync everything to /public_html/
$parentDir = dirname($dir);
$copiedToRoot = [];
if (basename($dir) === 'shribalajikripadham' && basename($parentDir) === 'public_html') {
    function copyRecursive($src, $dst) {
        $d = opendir($src);
        @mkdir($dst, 0755, true);
        while (false !== ($file = readdir($d))) {
            if ($file != '.' && $file != '..') {
                if (is_dir($src . '/' . $file)) {
                    copyRecursive($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($d);
    }
    copyRecursive($dir, $parentDir);
    $copiedToRoot[] = "Copied entire folder to public_html root!";
}

// 3. Connect to Database and Install Tables
define('DB_HOST', 'localhost');
define('DB_NAME', 'u237101617_balaji');
define('DB_USER', 'u237101617_ankitantim0');
define('DB_PASS', 'Aa@8006518960');

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "error" => "MySQL Connection Failed: " . $e->getMessage(),
        "fixed_files" => $fixed,
        "copied_to_root" => $copiedToRoot
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$queries = [
    "CREATE TABLE IF NOT EXISTS ashram_settings (
        id INT PRIMARY KEY DEFAULT 1,
        ashram_name VARCHAR(255) NOT NULL DEFAULT 'श्री बालाजी कृपा धाम',
        ashram_latitude DECIMAL(11, 8) NOT NULL DEFAULT 28.3972915,
        ashram_longitude DECIMAL(11, 8) NOT NULL DEFAULT 78.1460410,
        allowed_radius_meters DECIMAL(8, 2) NOT NULL DEFAULT 200.0,
        is_geofence_enforced TINYINT(1) NOT NULL DEFAULT 1,
        is_outstation_advance_allowed TINYINT(1) NOT NULL DEFAULT 1,
        outstation_min_distance_km DECIMAL(6, 2) NOT NULL DEFAULT 30.0,
        current_serving_token INT NOT NULL DEFAULT 0,
        daily_token_limit INT NOT NULL DEFAULT 1000,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

    "INSERT IGNORE INTO ashram_settings (id, ashram_name, ashram_latitude, ashram_longitude, allowed_radius_meters, is_geofence_enforced, is_outstation_advance_allowed, outstation_min_distance_km)
    VALUES (1, 'श्री बालाजी कृपा धाम', 28.3972915, 78.1460410, 200.0, 1, 1, 30.0);",

    "CREATE TABLE IF NOT EXISTS tokens (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        darbar_date DATE NOT NULL,
        token_number INT NOT NULL,
        patient_name VARCHAR(150) NOT NULL,
        phone_number VARCHAR(20) NOT NULL,
        city VARCHAR(100) NOT NULL DEFAULT '',
        device_id VARCHAR(100) DEFAULT '',
        latitude DECIMAL(11, 8) DEFAULT 0.0,
        longitude DECIMAL(11, 8) DEFAULT 0.0,
        distance_km DECIMAL(8, 2) DEFAULT 0.0,
        origin_address TEXT,
        destination_address TEXT,
        photo_url VARCHAR(500) DEFAULT '',
        status ENUM('WAITING', 'SERVING', 'COMPLETED', 'CANCELLED') NOT NULL DEFAULT 'WAITING',
        registered_by VARCHAR(50) NOT NULL DEFAULT 'ONLINE_DEVOTEE',
        is_darshan_completed TINYINT(1) NOT NULL DEFAULT 0,
        darshan_completed_at BIGINT DEFAULT NULL,
        created_at BIGINT NOT NULL,
        server_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_date_token (darbar_date, token_number),
        INDEX idx_date_status (darbar_date, status),
        INDEX idx_phone (phone_number),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

    "CREATE TABLE IF NOT EXISTS devotee_profiles (
        phone_number VARCHAR(20) PRIMARY KEY,
        patient_name VARCHAR(150) NOT NULL,
        city VARCHAR(100) NOT NULL DEFAULT '',
        photo_url VARCHAR(500) DEFAULT '',
        face_vector_b64 MEDIUMTEXT,
        total_darshans INT NOT NULL DEFAULT 1,
        last_darbar_date DATE,
        registered_by VARCHAR(50) DEFAULT 'APP',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
];

foreach ($queries as $q) {
    $pdo->exec($q);
}

// Check tables
$stmt = $pdo->query("SHOW TABLES");
$tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode([
    "success" => true,
    "message" => "श्री बालाजी कृपा धाम डेटाबेस और बैकएंड सफलतापूर्वक सक्रिय और रिपेयर हो गया!",
    "database" => DB_NAME,
    "active_tables" => $tables,
    "fixed_files" => $fixed,
    "copied_to_root" => $copiedToRoot,
    "root_api_url" => "https://shribalajikripadham.online/api/",
    "subfolder_api_url" => "https://shribalajikripadham.online/shribalajikripadham/api/"
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
